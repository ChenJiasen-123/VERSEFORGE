"""Validated PCM WAV transport input; resampling is kept off the robot path."""
import hashlib
import wave
from pathlib import Path


def read_robot_wav(path, *, max_seconds=180):
    with wave.open(str(path), 'rb') as wav:
        rate, channels, width = wav.getframerate(), wav.getnchannels(), wav.getsampwidth()
        frames = wav.getnframes()
        if wav.getcomptype() != 'NONE' or channels != 1 or width != 2 or rate not in (16000, 24000):
            raise ValueError('机器人音频须为16000或24000Hz、单声道、16位PCM WAV')
        if not 0 < frames <= max_seconds * rate:
            raise ValueError('音频为空或超过时长上限')
        data = wav.readframes(frames)
        if len(data) != frames * 2:
            raise ValueError('音频数据不完整')
    return data, {'sample_rate': rate, 'channels': channels, 'sample_width': width,
                  'frames': frames, 'duration_seconds': frames / rate,
                  'pcm_sha256': hashlib.sha256(data).hexdigest()}


def convert_wav(source, destination, *, gain=0.7, target_rate=16000):
    # audioop is available in this project's Windows Python 3.12 and robot Python 3.10.
    import audioop
    if not 0 < gain <= 4:
        raise ValueError('输出增益须大于0且不超过4')
    if type(target_rate) is not int or target_rate not in (16000, 24000):
        raise ValueError('目标采样率须为16000或24000Hz')
    with wave.open(str(source), 'rb') as wav:
        rate, channels, width = wav.getframerate(), wav.getnchannels(), wav.getsampwidth()
        if wav.getcomptype() != 'NONE' or channels not in (1, 2) or width not in (1, 2, 3, 4):
            raise ValueError('不支持的源WAV格式')
        pcm = wav.readframes(wav.getnframes())
    if width == 1:
        pcm = audioop.bias(pcm, 1, -128)
    if width != 2:
        pcm = audioop.lin2lin(pcm, width, 2)
    if channels == 2:
        pcm = audioop.tomono(pcm, 2, 0.5, 0.5)
    if rate != target_rate:
        pcm, _ = audioop.ratecv(pcm, 2, 1, rate, target_rate, None)
    requested_gain = gain
    input_peak = audioop.max(pcm, 2)
    if input_peak:
        gain = min(gain, 0.9 * 32767 / input_peak)
    pcm = audioop.mul(pcm, 2, gain)
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), 'wb') as wav:
        wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(target_rate)
        wav.writeframes(pcm)
    _, metadata = read_robot_wav(destination)
    return {**metadata, 'requested_gain': requested_gain, 'gain': gain,
            'peak': audioop.max(pcm, 2), 'rms': audioop.rms(pcm, 2)}


def pcm_chunks(data, *, chunk_ms=40, sample_rate=16000):
    if (type(chunk_ms) is not int or not 20 <= chunk_ms <= 100 or not data or len(data) % 2
            or type(sample_rate) is not int or sample_rate not in (16000, 24000)):
        raise ValueError('PCM分块参数无效')
    size = sample_rate * 2 * chunk_ms // 1000
    for pos in range(0, len(data), size):
        yield data[pos:pos + size]


def playback_packets(data, *, chunk_ms=40, sample_rate=16000):
    chunks = pcm_chunks(data, chunk_ms=chunk_ms, sample_rate=sample_rate)
    first = next(chunks)  # Validate before opening a robot playback session.
    yield 1, b''
    yield 2, first
    for chunk in chunks:
        yield 2, chunk
    yield 3, b''
