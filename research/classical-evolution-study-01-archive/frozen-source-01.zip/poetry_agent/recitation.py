"""Text-preserving delivery plans and SAPI SSML; no robot motion commands."""
import json
import copy
import re
import xml.etree.ElementTree as ET

NS = 'http://www.w3.org/2001/10/synthesis'
ET.register_namespace('', NS)
SYSTEM = '''你是诗歌朗读导演。保留诗稿每个字和标点，只规划声音，不改写作品。
现代诗重视行间关系，逐行停顿但不是每行等长；语气随经验推进，不全程激昂。
古体诗按句意处理停顿，不机械逐字顿；叮嘱、转折、收束可有轻重。
不要把所有词都重读，不用不断升高音调制造情感。默认成熟女声，清楚、坚定而有层次。
每个原诗行对应一个line_plan，其segments的text依序拼接必须逐字等于原行。
每行1—3个片段，尽量保留语流，片段的pause_ms表示读完后的停顿。
rate_percent整数-35至10；pitch_st整数-2至2；volume整数65至95；pause_ms整数0至2000。
朗诵字速比日常说话舒展，保留语流；行内一般150—350ms，行末一般700—1400ms，全诗末尾可1800ms。
只返回JSON：{"delivery":"整首情感推进，简短说明","line_plans":[{"segments":[{"text":"原文连续片段","pause_ms":400,"rate_percent":-5,"pitch_st":0,"volume":80,"reason":"该处的声音作用"}]}]}。
'''


def validate_plan(poem, plan):
    lines = poem.get('lines')
    if not isinstance(lines, list) or not lines or any(not isinstance(x, str) or not x for x in lines):
        raise ValueError('诗稿正文无效')
    rows = plan.get('line_plans')
    if not isinstance(rows, list) or len(rows) != len(lines):
        raise ValueError('朗读计划与诗稿行数不符')
    bounds = {'pause_ms': (0, 2000), 'rate_percent': (-35, 10), 'pitch_st': (-2, 2), 'volume': (65, 95)}
    for line, row in zip(lines, rows):
        segments = row.get('segments') if isinstance(row, dict) else None
        if not isinstance(segments, list) or not 1 <= len(segments) <= 3:
            raise ValueError('每行须有1—3个朗读片段')
        for part in segments:
            if not isinstance(part, dict) or not isinstance(part.get('text'), str) or not part['text']:
                raise ValueError('朗读片段无效')
            for key, (low, high) in bounds.items():
                if type(part.get(key)) is not int or not low <= part[key] <= high:
                    raise ValueError('朗读控制参数超出范围')
        if ''.join(p['text'] for p in segments) != line:
            raise ValueError('朗读计划改动或遗漏诗稿文字')
    return plan


def deliberate_delivery(poem, plan, genre):
    """Apply the user's slower-reading preference without touching words or pitch."""
    validate_plan(poem, plan)
    revised = copy.deepcopy(plan)
    minimum = 1400 if genre != 'modern' else 900
    for row in revised['line_plans']:
        for index, part in enumerate(row['segments']):
            part['rate_percent'] = max(-35, part['rate_percent'] - 25)
            if index == len(row['segments']) - 1:
                part['pause_ms'] = min(1800, max(minimum, round(part['pause_ms'] * 1.8)))
            else:
                part['pause_ms'] = max(300, part['pause_ms'])
    revised['line_plans'][-1]['segments'][-1]['pause_ms'] = 1800
    revised['delivery_profile'] = 'deliberate-user-feedback-01'
    return validate_plan(poem, revised)


def balanced_seven_delivery(poem, plan):
    """User-selected 2/2/3 rhythm, preserving the supplied seven-character text."""
    validate_plan(poem, plan)
    revised = copy.deepcopy(plan)
    for line, row in zip(poem['lines'], revised['line_plans']):
        positions = [i + 1 for i, char in enumerate(line) if re.fullmatch(r'[\u4e00-\u9fff]', char)]
        if len(positions) != 7:
            raise ValueError('二二三朗读节奏仅用于七言句')
        cuts = [positions[1], positions[3], len(line)]
        for i in (0, 1):
            while cuts[i] < len(line) and not re.fullmatch(r'[\u4e00-\u9fff]', line[cuts[i]]):
                cuts[i] += 1
        old = row['segments']
        starts = [0] + cuts[:-1]
        row['segments'] = [
            {**(old[0] if i == 0 else old[-1]), 'text': line[start:end],
             'rate_percent': -30, 'pause_ms': 350 if i < 2 else 1400,
             'reason': '用户确认的七言二二三对称节奏，保留本行轻重'}
            for i, (start, end) in enumerate(zip(starts, cuts))]
    revised['line_plans'][-1]['segments'][-1]['pause_ms'] = 1800
    revised['delivery_profile'] = 'seven-2-2-3-user-feedback-02'
    return validate_plan(poem, revised)


def plan_recitation(poem, genre, client):
    payload = {'poem': poem, 'genre': genre}
    for attempt in range(2):
        response = client.complete(SYSTEM, json.dumps(payload, ensure_ascii=False),
                                   timeout=60, max_tokens=6000, thinking='disabled')
        try:
            plan = validate_plan(poem, json.loads(response['content']))
            break
        except (ValueError, TypeError, AttributeError):
            if attempt == 1:
                raise
            payload['repair_instruction'] = '上一响应格式或逐字核对失败。重新给出完整有效JSON，覆盖每一原诗行，不能改字或漏行。'
    return {'poem': poem, 'genre': genre, 'plan': plan, 'usage': response.get('usage', {}),
            'response_metadata': response.get('response_metadata', {}), 'planning_attempts': attempt + 1,
            'listening_verified': False}


def to_ssml(poem, plan, *, flat=False, pronunciation_aliases=None):
    validate_plan(poem, plan)
    speak = ET.Element(f'{{{NS}}}speak', {'version': '1.0', '{http://www.w3.org/XML/1998/namespace}lang': 'zh-CN'})
    aliases = pronunciation_aliases or {}
    for row in plan['line_plans']:
        parts = row['segments']
        if flat:
            parts = [{'text': ''.join(x['text'] for x in parts), 'pause_ms': 350,
                      'rate_percent': 0, 'pitch_st': 0, 'volume': 80}]
        for part in parts:
            prosody = ET.SubElement(speak, f'{{{NS}}}prosody', {
                'rate': f"{part['rate_percent']:+d}%", 'pitch': f"{part['pitch_st']:+d}st",
                'volume': str(part['volume'])})
            text = part['text']
            # Explicit editor-supplied homophones; never rewrite the saved poem.
            matches = [(text.find(word), word, alias) for word, alias in aliases.items() if word in text]
            if len(matches) > 1:
                raise ValueError('单片段多个读音替代须先拆分，避免重叠')
            if matches:
                pos, word, alias = matches[0]
                prosody.text = text[:pos]
                sub = ET.SubElement(prosody, f'{{{NS}}}sub', {'alias': alias})
                sub.text = word
                sub.tail = text[pos + len(word):]
            else:
                prosody.text = text
            if part['pause_ms']:
                ET.SubElement(speak, f'{{{NS}}}break', {'time': f"{part['pause_ms']}ms"})
    return ET.tostring(speak, encoding='unicode')
